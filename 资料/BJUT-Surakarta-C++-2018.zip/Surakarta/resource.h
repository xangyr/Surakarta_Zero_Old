//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Surakarta.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SURAKATYPE                  129
#define IDB_BITMAP1                     133
#define IDB_BITMAP2                     134
#define IDB_BITMAP3                     135
#define IDB_BITMAP4                     136
#define IDB_BITMAP5                     137
#define IDB_BITMAP6                     138
#define IDD_DIALOG1                     139
#define IDD_DIALOG2                     140
#define IDB_BITMAP7                     141
#define IDB_BITMAP8                     142
#define IDC_EDIT1                       1000
#define IDC_RED                         1001
#define IDC_BLACK                       1002
#define IDC_COMPUTER                    1003
#define IDC_BRAIN                       1004
#define IDC_LISTENGINE                  1011
#define IDC_PLY                         1013
#define ID_BEGIN                        32771
#define ID_REBEGIN                      32772
#define ID_BACK                         32773
#define ID_SET                          32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
